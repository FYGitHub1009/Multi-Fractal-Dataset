from functools import partial

from cv2 import cvtColor, COLOR_HSV2RGB
import numba
import numpy as np


# IFSフラクタル座標計算
@numba.njit(cache=True)
def iterate(sys, n_iter, ps=None):
    '''Compute points in the fractal defined by the system `sys` by random iteration. `n_iter` iterations
    are performed, and a transform is sampled at each iteration according to the probabilites defined by
    `ps`.
    
    Args:
        sys (np.ndarray): array of shape (n, 2, 3), containing the affine transform parameters.
        n_iter (int): number of iterations/points to calculate.
        ps (Optional[array-like]): length-n array of probabilites. If None (default), the probabilites are
            calculated to be proportional to the determinants of the affine transformation matrices.
    
    Returns:
        ndarray of shape (n_iter, 2) containing the (x, y) coordinates of the generated points.
    '''
    det = sys[:, 0, 0] * sys[:, 1, 1] - sys[:, 0, 1] * sys[:, 1, 0]
    # 確率が指定されていない場合、detから計算
    if ps is None:
        # パラメータセット毎の確率
        ps = np.abs(det)
        # 全体で1になるように正規化
        ps = ps / ps.sum()
    # 累積確率、0-1の乱数でどのパラメータセットを使うか決めるため
    ps = np.cumsum(ps)
    
    # 全フラクタル点の座標
    coords = np.empty((n_iter, 2))

    # starting point is $v = (I-A_1)^(-1) b$ since this point is gaurenteed to be in the set
    # (assuming that A_1 is contractive) (A_1 = sys[0])
    s = 1 / (1 + det[0] - sys[0, 0, 0] - sys[0, 1, 1])
    x = s * ((1 - sys[0, 1, 1]) * sys[0, 0, 2] + sys[0, 0, 1] * sys[0, 1, 2])
    y = s * ((1 - sys[0, 0, 0]) * sys[0, 1, 2] + sys[0, 1, 0] * sys[0, 0, 2])

    for i in range(n_iter):
        # 0-1の一様乱数の生成
        r = np.random.rand()
        # 使用するパラメータセットの特定
        for k in range(len(ps)):
            if r < ps[k]: break
        # パラメータセット
        a, b, e, c, d, f = sys[k].ravel()
        # 次座標の計算
        xt = x
        x = a * xt + b * y + e
        y = c * xt + d * y + f
        coords[i] = x, y

        # 発散した場合はブレイク
        if not np.isfinite(x) or not np.isfinite(y): break  # if contractivity is satisfied, can remove this check
    return coords


@numba.njit(cache=True)
def minmax(coords):
    '''Returns both the minimum and maximum values along the 0 axis of an array with shape (n, 2). This only
    requires a single pass through the array, and is faster than calling np.min and np.max seperately.
    
    Args:
        coords (np.ndarray): an array of shape (n, 2)
        
    Returns:
        Two ndarrays of shape (2,), the first containing the minimum values and the second containing the maximums
    '''
    # x,y座標の最大、最小値
    mins = np.full(2, np.inf)
    maxs = np.full(2, -np.inf)
    for i in range(len(coords)):
        x, y = coords[i]
        if x < mins[0]: mins[0] = x
        if y < mins[1]: mins[1] = y
        if x > maxs[0]: maxs[0] = x
        if y > maxs[1]: maxs[1] = y
    return mins, maxs


@numba.njit(cache=True)
def _extent(region):
    x1, y1, x2, y2 = region
    xspan = x2 - x1
    xspan = xspan if xspan > 0 else 1
    yspan = y2 - y1
    yspan = yspan if yspan > 0 else 1
    return xspan, yspan



@numba.njit(cache=True)
def _render_binary(coords, s, region):
    '''Renders a square, binary image from coordinate points and a given region.
    
    Args:
        coords (np.ndarray): coordinate array of shape (n, 2).
        s (int): side length of the rendered image. The image will have width = height = s.
        region (np.ndarray): array of shape (4,), containing [minx, miny, maxx, maxy]. These four values
            define the region in coordinate space that will be rendered to the image. Coordinate points
            that fall outside the bounds of the region will be ignored.
    
    Returns:
        A binary image as an ndarray of shape (s, s).
    '''
    imgb = np.zeros((s, s), dtype=np.uint8)
    xspan, yspan = _extent(region)
    xscale = (s-1) / xspan
    yscale = (s-1) / yspan
    xmin, ymin = region[0], region[1]
    for i in range(len(coords)):
        r = int((coords[i,0] - xmin) * xscale)
        c = int((coords[i,1] - ymin) * yscale)
        if r >= 0 and r < s and c >= 0 and c < s:
            imgb[r, c] = 1
    return imgb



@numba.njit(cache=True)
def _render_binary_patch(coords, s, region, patch):
    '''Renders a square, binary image from coordinate points and a given region. Instead of rendering a
    single point for each coordinate, a 3x3 patch is rendered, centered on the coordinate.

    Args:
        coords (np.ndarray): coordinate array of shape (n, 2).
        s (int): side length of the rendered image. The image will have width = height = s.
        region (np.ndarray): array of shape (4,), containing [minx, miny, maxx, maxy]. These four values
            define the region in coordinate space that will be rendered to the image. Coordinate points
            that fall outside the bounds of the region will be ignored.
        patch (np.ndarray): array of shape (3, 3), where each value is either 0 or 1 (binary).

    Returns:
        A grayscale image as an ndarray of shape (s, s).
    '''
    # ブランク画像作成
    imgb = np.zeros((s, s), dtype=np.uint8)
    # x幅、y幅
    xspan, yspan = _extent(region)
    # xy軸方向の拡大係数
    xscale = (s-1) / xspan
    yscale = (s-1) / yspan
    # xy軸最小値
    xmin, ymin = region[0], region[1]
    for i in range(len(coords)):
        # ピクセル座標の計算
        rr = int((coords[i,0] - xmin) * xscale)
        cc = int((coords[i,1] - ymin) * yscale)
        # patch処理
        for j in range(len(patch)):
            # マスクが1ならそのまま、0or2なら左右に書き込みでそのピクセルはブランク
            r = rr + patch[j, 0] - 1
            c = cc + patch[j, 1] - 1
            if r >= 0 and r < s and c >= 0 and c < s:
                imgb[r, c] = 1
    return imgb
    

@numba.njit(cache=True)
def _render_graded(coords, s, region):
    '''Renders a square, grayscale image from coordinate points and a given region. The grayscale values for
    a given pixel is proportional to the number of coordinate points that land on that pixel.
    
    See _render_binary for an explanation of the arguments.
    '''
    # ブランク画像、0-1の小数点になるので、floatで
    imgf = np.zeros((s, s), dtype=np.float64)
    # x,yの幅
    xspan, yspan = _extent(region)
    # ピクセル位置スケーリング
    xscale = (s-1) / xspan
    yscale = (s-1) / yspan
    xmin, ymin = region[0], region[1]
    for i in range(len(coords)):
        # ピクセル座標計算
        r = int((coords[i,0] - xmin) * xscale)
        c = int((coords[i,1] - ymin) * yscale)
        if r >= 0 and r < s and c >= 0 and c < s:
            # 明暗つけるため加算する
            imgf[r, c] += 1
    # 正規化
    mval = imgf.max()
    if mval > 0:
        imgf /= mval
    return imgf


@numba.njit(cache=True)
def _render_graded_patch(coords, s, region, patch):
    '''Renders a square, grayscale image from coordinate points and a given region. The grayscale values for
    a given pixel is proportional to the number of coordinate points that land on that pixel. Instead of rendering
    a single point for each coordinate, a 3x3 patch is rendered, centered on the coordinate.
    
    See _render_binary_patch for an explanation of the arguments.
    '''
    imgf = np.zeros((s, s), dtype=np.float64)
    xspan, yspan = _extent(region)
    xscale = (s-1) / xspan
    yscale = (s-1) / yspan
    xmin, ymin = region[0], region[1]
    for i in range(len(coords)):
        rr = int((coords[i,0] - xmin) * xscale)
        cc = int((coords[i,1] - ymin) * yscale)
        for j in range(len(patch)):
            r = rr + patch[j, 0] - 1
            c = cc + patch[j, 1] - 1
            if r >= 0 and r < s and c >= 0 and c < s:
                imgf[r, c] += 1
    mval = imgf.max()
    if mval > 0:
        imgf /= mval
    return imgf


# フラクタル描画
def render(coords, s=256, binary=True, region=None, patch=False):
    '''Render an image from a set of coordinates and an optionally specified region.
    
    Args:
        coords (np.ndarray): coordinate array of shape (n, 2).
        s (int): side length of the rendered image. The image will have width = height = s.
        binary (bool): if True, render a binary image; otherwise, render a grayscale image, where the grayscale
            value is proportional to the number of coordinates that map to the pixel.
        region (Optional[np.ndarray]): array of shape (4,), containing [minx, miny, maxx, maxy]. These four
            values define the region in coordinate space that will be rendered to the image. Coordinate points
            that fall outside the bounds of the region will be ignored. If None (default), the minimum and
            maximum coordinate values are used.
        patch (bool): if False, render each coordinate as a single point. If True, renders a 3x3 patch centered
            at each coordinate. The patch is randomly sampled (each value is chosen uniformly from [0, 1]).

    Returns:
        An image (either grayscale or binary, depending) as an ndarray of shape (s, s).
    '''

    # 範囲指定がない場合
    if region is None:
        # フラクタル点座標の最大、最小範囲で切り出し
        region = np.concatenate(minmax(coords))
    else:
        region = np.asarray(region)
    
    # パッチ処理有りの場合
    if patch:
        # 3x3のマスク、だがどうも2もあるような
        p = np.stack(np.divmod(np.arange(9)[np.random.randint(0, 2, (9,), dtype=bool)], 3), 1)

    if binary:
        if patch:
            # patch処理ありの白黒画像
            return _render_binary_patch(coords, s, region, p)
        else:
            # patch処理なし白黒画像
            return _render_binary(coords, s, region)
    else:
        # カラー指定の場合、とりあえず輝度値のみ計算
        if patch:
            # patc処理ありカラー画像
            return _render_graded_patch(coords, s, region, p)
        else:
            # patc処理なしカラー画像
            return _render_graded(coords, s, region)


# HSV空間で色付け関数
@numba.njit(cache=True)
def _hsv_colorize(rendered, min_sat=0.3, min_val=0.5):
    '''Creates a 3-channel HSV image from a 1-channel gray image.
    '''
    h, w = rendered.shape[:2]
    img = np.empty((h, w, 3), dtype=np.uint8)

    # 基準Hue
    hue_shift = np.random.rand() * 255
    # 彩度
    sat = np.uint8(np.random.uniform(min_sat, 1) * 255)
    # 明度
    val = np.uint8(np.random.uniform(min_val, 1) * 255)

    for i in range(h):
        for j in range(w):
            x = rendered[i, j]
            if x > 0:
                img[i, j, 0] = np.uint8(x * 255 + hue_shift)  # implicit MOD(256)
                img[i, j, 1] = sat
                img[i, j, 2] = val
            else:
                img[i, j, 0] = 0
                img[i, j, 1] = 0
                img[i, j, 2] = 0
    return img


@numba.njit(cache=True)
def _hsv_colorize2(rendered, min_sat=0.3, min_val=0.5):
    h, w = rendered.shape[:2]
    img = np.empty((h, w, 3), dtype=np.uint8)

    hue_scale = np.random.uniform(0.5, 1) * 255
    hue_shift = np.random.rand() * 255

    # diamond-square
    sat_scale = np.random.uniform(0.1, 0.3) * 255
    sat_shift = np.random.uniform(0.2, 0.4) * 255
    val_scale = np.random.uniform(0.3, 0.6) * 255
    val_shift = np.random.uniform(0.2, 0.4) * 255

    # ちょっと明るく
    #sat_scale = np.random.uniform(0.1, 0.3) * 255
    # sat_shift = np.random.uniform(0.5, 0.7) * 255
    #val_scale = np.random.uniform(0.3, 0.6) * 255
    #val_shift = np.random.uniform(0.5, 0.7) * 255

    for i in range(h):
        for j in range(w):
            x = rendered[i, j]
            if x > 0:
                img[i, j, 0] = np.uint8(x * hue_scale + hue_shift)  # implicit MOD(256)
                img[i, j, 1] = np.uint8(min(x * sat_scale + sat_shift, 255))
                img[i, j, 2] = np.uint8(min(x * val_scale + val_shift, 255))
            else:
                img[i, j, 0] = 0
                img[i, j, 1] = 0
                img[i, j, 2] = 0
    return img


# 前景画像埋め込み
@numba.njit(cache=True)
def composite(fg, bg):
    '''Copy nonzero pixels from fg into bg. Modifies bg in-place.'''
    for i in range(fg.shape[0]):
        for j in range(fg.shape[1]):
            if fg[i, j, 0] != 0 or fg[i, j, 1] != 0 or fg[i, j, 2] != 0:
                bg[i, j] = fg[i, j]
    return bg


# カラー画像化
def colorize(rendered, min_sat=0.3, min_val=0.5):
    '''Turns a grayscale image into a color image, where the colors are randomly chosen as explained below.
    
    First, the grayscale values are converted to the range [0, 255]. A reference hue value h is chosen
    uniformly from [0, 255], and the hue for each pixel p becomes (p + h) mod 256. Then global saturation
    and value scales are chosen uniformly from the ranges [min_sat, 1] and [min_val, 1]. Finally, the image
    is converted to RGB.
    
    Args:
        rendered (np.ndarray): grayscale image of shape (w, h), with values in the range [0, 1].
        min_sat (float): minimum "saturation" value, defining the range of possible saturation values to draw from.
        min_val (float): minimum "value" value, defining the range of possible "value" (as in light/dark) values to
            draw from.

    Returns:
        A color image as an ndarray of shape (w, h, 3).
    '''
    # HSV空間で色付け
    #img = _hsv_colorize(rendered, min_sat, min_val)
    img = _hsv_colorize2(rendered, min_sat, min_val)
    # HSV->RGB変換
    cvtColor(img, COLOR_HSV2RGB, dst=img)
    return img
