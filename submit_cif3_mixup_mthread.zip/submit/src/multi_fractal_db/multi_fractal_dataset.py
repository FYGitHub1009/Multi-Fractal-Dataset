from functools import partial
import pickle
from typing import Callable, Optional, Tuple, Union
import warnings

from cv2 import GaussianBlur
import numpy as np
import torch
import torchvision

from multi_fractal_db import diamondsquare, ifs
from multi_fractal_db.multi_fractal_generator import MultiGenerator


class MultiFractalDataset(object):
    def __init__(
        self,
        ifs_params: object,
        num_systems: int = 100,
        num_class: int = 100,
        per_class: int = 100,
        generator: Optional[Callable] = None,
        period: int = 2,
    ):
        # IFSシステム数
        self.num_systems = num_systems
        # クラス数
        self.num_class = num_class
        # クラスあたりの画像枚数
        self.per_class = per_class
        # クラスあたりのIFSシステム数
        self.per_system = num_class * per_class / num_systems
        # IFSシステムパラメータ
        self.params = ifs_params['params'][:num_systems]

        # なぜかここMultiGeneratorが生成されてしまうのでコメントアウト
        self.generator = generator #or MultiGenerator()

        # キャッシュ画像をすべて作成
        while len(self.generator.cache['fg']) < self.generator.cache_size:
            for isys in range(num_systems):
                # 代表クラス番号
                k = np.random.default_rng().integers(0, num_class)
                self.generator.add_sample(self.params[isys]['system'], label=k)

        self.steps = 0
        self.period = period

    def __len__(self):
        return self.num_class * self.per_class

    def get_label(self, idx):
        return int(idx // self.num_class)

    def get_system(self, idx):
        return int(idx // self.per_system)

    def __getitem__(self, idx):
        # whether it's time to render a new fractal or not
        self.steps = (self.steps + 1) % self.period
        sample = self.steps == 0
        # IFSシステム番号
        sysidx = self.get_system(idx)
        # ラベル取得
        label = self.get_label(idx)
        # IFSパラメータ取得
        params = self.params[sysidx]['system']
        # 混合画像と混合ラベル
        img, labels = self.generator(params, label=label, new_sample=sample)
        #img = torch.from_numpy(img).float().mul_(1/255.).permute(2,0,1)

        return img, labels
