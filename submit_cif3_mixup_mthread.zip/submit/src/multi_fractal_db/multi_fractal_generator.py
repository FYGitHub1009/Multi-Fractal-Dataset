from functools import partial
from typing import Callable, Optional, Tuple, Union

from cv2 import GaussianBlur, resize, INTER_LINEAR, getRotationMatrix2D, warpAffine
import numpy as np

from multi_fractal_db import diamondsquare, ifs


class _GeneratorBase(object):
    def __init__(
        self,
        # 画像サイズ
        size: int = 224,
        # jit方法、Trueもしくは文字列を受け入れる
        jitter_params: Union[bool, str] = True,
        flips: bool = True,
        # ボケの標準偏差
        sigma: Optional[Tuple[float, float]] = (0.5, 1.0),
        blur_p: Optional[float] = 0.5,
        # フラクタル座標点数
        niter = 100000,
        # patch処理有無
        patch = True,
    ):
        self.size = size
        self.jitter_params = jitter_params
        self.flips = flips
        self.sigma = sigma
        self.blur_p = blur_p
        self.niter = niter
        self.patch = patch

        self.rng = np.random.default_rng()
        self.cache = {'fg': [], 'bg': []}
        # jit関数定義
        self._set_jitter()

    # jit関数
    def _set_jitter(self):
        # jit指定が文字列の場合
        if isinstance(self.jitter_params, str):
            if self.jitter_params.startswith('fractaldb'):
                k = int(self.jitter_params.split('-')[1]) / 10
                choices = np.linspace(1-2*k, 1+2*k, 5, endpoint=True)
                self.jitter_fnc = partial(self._fractaldb_jitter, choices=choices)
            if self.jitter_params.startswith('svd'):
                self.jitter_fnc = self._svd_jitter
            if self.jitter_params.startswith('sval'):
                self.jitter_fnc = self._sval_jitter
        elif self.jitter_params:
            # defualt
            self.jitter_fnc = self._basic_jitter
        else:
            # そのまま返す
            self.jitter_fnc = lambda x: x


    def _fractaldb_jitter(self, sys, choices=(.8,.9,1,1.1,1.2)):
        n = len(sys)
        y, x = np.divmod(self.rng.integers(0, 6, (n,)), 3)
        sys[range(n), y, x] *= self.rng.choice(choices)
        return sys


    # デフォルトのJitter関数
    def _basic_jitter(self, sys, prange=(0.8, 1.1)):
        # tweak system parameters--randomly choose one transform and scale it
        # this actually amounts to scaling the singular values by a random factor
        # IFSパラメータの全要素数
        n = len(sys)
        # どれか1要素を係数かけて微笑変動させる
        sys[self.rng.integers(0, n)] *= self.rng.uniform(*prange)
        return sys


    def _svd_jitter(self, sys):
        '''Jitter the parameters of one of the systems functions, in SVD space.'''
        k = self.rng.integers(0, len(sys) * 3)
        sidx, pidx = divmod(k, 3)
        if pidx < 2:
            q = self.rng.uniform(-0.5, 0.5)
            u, s, v = np.linalg.svd(sys[sidx, :, :2])
            cq, sq = np.cos(q), np.sin(q)
            r = np.array([[cq, -sq], [sq, cq]])
            if pidx == 0:
                u = r @ u
            else:
                v = r @ v
            sys[sidx, :, :2] = (u * s[None,:]) @ v
        else:
            x, y = self.rng.uniform(-0.5, 0.5, (2,))
            sys[sidx, :, 2] += [x, y]
        return sys


    def _sval_jitter(self, sys):
        k = self.rng.integers(0, sys.shape[0])
        svs = np.linalg.svd(sys[...,:2], compute_uv=False)
        fac = (svs * [1, 2]).sum()
        minf = 0.5 * (5 + sys.shape[0])
        maxf = minf + 0.5
        ss = svs[k, 0] + 2 * svs[k, 1]
        smin = (minf - fac + ss) / ss
        smax = (maxf - fac + ss) / ss
        m = self.rng.uniform(smin, smax)
        u, s, v = np.linalg.svd(sys[k, :, :2])
        s = s * m
        sys[k, :, :2] = (u * s[None]) @ v
        return sys


    # IFSパラメータ微小変動
    def jitter(self, sys):
        # 4回、微小変動を起こす
        attempts = 4 if self.jitter_params else 0
        for i in range(attempts):
            # jitter system parameters
            sysc = sys.copy()
            sysc = self.jitter_fnc(sysc)
            # 特異値分解、対角行列の特異値のみ計算
            # occasionally the modified parameters cause the system to explode
            svd = np.linalg.svd(sysc[:,:,:2], compute_uv=False)
            # 1を超えている場合発散するので再度jitする
            if svd.max() > 1: continue
            break
        else:
            # fall back on not jittering the parameters
            sysc = sys
        return sysc
    
    
    # IFSフラクタル座標と範囲の計算
    def _iterate(self, sys):
        rng = self.rng

        # 全フラクタル点の座標を計算
        coords = ifs.iterate(sys, self.niter)
        
        # フラクタル点の座標範囲、[xmin, ymin, xmax, ymax]
        region = np.concatenate(ifs.minmax(coords))

        return coords, region


    def render(self, sys):
        raise NotImplementedError()


    # データ拡張(RandomFlip)
    def random_flips(self, img):
        # random flips/rotations
        if self.rng.random() > 0.5:
            # 縦横転置
            img = img.transpose(1, 0)
        if self.rng.random() > 0.5:
            # 上下反転
            img = img[::-1]
        if self.rng.random() > 0.5:
            # 左右反転
            img = img[:, ::-1]
        # 配列のメモリ連続性を確保するため
        img = np.ascontiguousarray(img)
        return img


    # フラクタル画像のカラー化
    def to_color(self, img):
        # カラー画像化
        return ifs.colorize(img)


    # 白黒画像
    def to_gray(self, img):
        # バイナリ画像なので中間の127の灰色画像で、3チャンネルにしておく
        return (img * 127).astype(np.uint8)[..., None].repeat(3, axis=2)


    # 背景画像を作成
    def render_background(self):
        # 幾何模様のカラー背景作成
        bg = diamondsquare.colorized_ds(self.size)
        # 背景を暗くする
        #bg = bg * 0.5
        return bg


    # 背景に前景を埋め込み
    def composite(self, foreground, base, idx=None):
        return ifs.composite(foreground, base)


    # データ拡張(ボカし)
    def random_blur(self, img):
        # 標準偏差取得
        sigma = self.rng.uniform(*self.sigma)
        # 画像平坦化
        img = GaussianBlur(img, (3, 3), sigma, dst=img)
        return img
    

    def generate(self, sys):
        raise NotImplementedError()


    def __call__(self, sys, *args, **kwargs):
        return self.generate(sys, *args, **kwargs)



class MultiGenerator(_GeneratorBase):
    def __init__(
        self,
        # 画像サイズ
        size: int = 224,
        # キャッシュサイズ
        cache_size: int = 100,
        # 混合数
        n_objects: Tuple[int, int] = (1, 5),
        # 埋め込み画像サイズ
        size_range: Tuple[float, float] = (0.2, 0.6),
        # jitパラメータ、デフォルトではなし
        jitter_params: Union[bool, str] = False,
        # データ拡張(縦横、左右、上下反転)フラグ
        flips: bool = True,
        # ボカしの標準偏差
        sigma: Optional[Tuple[float, float]] = (0.5, 1.0),
        # データ拡張(ボケ実施確率)
        blur_p: Optional[float] = 0.5,
        # カラー画像フラグ
        color = True,
        # 背景画像の付与の有無
        background = True,
        # フラクタル点数
        niter = 100000,
        # patch処理実施有無
        patch = True,
        # 混合画像の採用確率?
        nobj_p = None,
    ):
        self.size = size
        self.n_objects = n_objects
        self.size_range = size_range
        self.jitter_params = jitter_params
        self.flips = flips
        self.sigma = sigma
        self.blur_p = blur_p
        self.color = color
        self.background = background
        self.niter = niter
        self.patch = patch

        # 乱数生成器
        self.rng = np.random.default_rng(seed=0)
        
        # キャッシュサイズ
        self.cache_size = cache_size
        # 前景と背景のキャッシュ
        self.cache = {'fg': [], 'bg': [], 'label': []}
        self.idx = 0

        # 混合確率
        if nobj_p is None:
            # 等確率
            self.nobj_p = np.ones(n_objects[1] - n_objects[0] + 1)
        else:
            self.nobj_p = np.array(nobj_p, dtype=np.float64)
        self.nobj_p /= self.nobj_p.sum()

        # jit関数設定
        self._set_jitter()


    def __len__(self):
        # 前景キャッシュ数を返す
        return len(self.cache['fg'])


    def _update_cache(self, fg, bg, label):
        if len(self) < self.cache_size:
            # キャッシュサイズ以下であれば追記
            self.cache['fg'].append(fg)
            self.cache['bg'].append(bg)
            self.cache['label'].append(label)
        else:
            # idx番目に追加
            self.cache['fg'][self.idx] = fg
            self.cache['bg'][self.idx] = bg
            self.cache['label'][self.idx] = label
        # キャッシュ番号
        self.idx = (self.idx + 1) % self.cache_size


    # 前景のフラクタル画像作成
    def render(self, sys):
        # 乱数生成器コピー
        rng = self.rng
        # フラクタル座標と範囲
        coords, region = self._iterate(sys)
        # render the fractal at half resolution--it will be resized during generation phase
        img = ifs.render(coords, self.size, binary=False, region=region, patch=self.patch)
        return img


    # キャッシュに前景と背景画像を追加
    def add_sample(self, sys, label=-1):
        # IFSパラメータの微少変動
        sysc = self.jitter(sys)
        # フラクタル画像生成
        frac = self.render(sysc)
        # 背景画像の生成
        bg = self.render_background()
        # MixUPとかできないのでラベルは使わない
        # キャッシュに追加
        self._update_cache(frac, bg, label)


    # Multi-Fractal画像を作成
    def generate(self, sys, label=-1, new_sample=True):
        # 乱数生成器コピー
        rng = self.rng

        # 新規追加しない、
        # インスタンス時に全キャッシュ作成済みでそこからとってくる
        #if new_sample:
        #    self.add_sample(sys, label)

        # 背景画像をキャッシュ内からランダムに選択
        idx = rng.integers(0, len(self))
        img = self.cache['bg'][idx].copy()
        # 背景なしの場合はブランク画像
        if self.background==False:
            img = np.zeros(img.shape, np.uint8)
        
        # ラベルは使わない
        labels = []

        # 混合数を乱数選択
        n = rng.choice(range(self.n_objects[0], self.n_objects[1]+1), p=self.nobj_p)
        # キャッシュサイズでキャップ
        n = min(n, len(self))

        # 混合数回分繰り返し
        for i in range(n):
            # キャッシュ番号選択
            idx = rng.integers(0, len(self))

            # ラベルリストに追加
            labels.append(self.cache['label'][idx])

            # 前景画像取得
            fg = self.cache['fg'][idx]

            # データ拡張(転置、水平、上下反転)
            # random flips
            if self.flips:
                fg = self.random_flips(fg)

            # colorize
            if self.color:
                # カラー画像化
                fg = self.to_color(fg)
            else:
                # 白黒画像化
                fg = self.to_gray(fg)

            # 0.2-0.6倍でリサイズ
            # リサイズ倍率
            f = rng.uniform(*self.size_range)
            # リサイズ
            s = int(f * self.size)
            fg = resize(fg, (s, s), interpolation=INTER_LINEAR)

            # データ拡張(回転)
            if self.blur_p and rng.random() > self.blur_p:
                # 回転角度
                angle = rng.integers(-45, 45, 1)[0]
                # 回転中心
                height, width, channel = fg.shape                                    
                center = (int(width/2), int(height/2))
                # 等倍
                scale = 1.0
                #getRotationMatrix2D関数を使用
                trans = getRotationMatrix2D(center, angle , scale)
                #アフィン変換
                fg = warpAffine(fg, trans, (width,height))

            # ランダム埋め込み位置
            # random location
            #x, y = rng.integers(-(s//2), self.size-(s//2), 2)
            # 見切れ防止
            x, y = rng.integers(0, self.size-s, 2)
            # 見切れ範囲除外
            x1 = 0 if x >= 0 else -x
            x2 = s if x < self.size - s else self.size - x
            y1 = 0 if y >= 0 else -y
            y2 = s if y < self.size - s else self.size - y
            fg = fg[y1:y2, x1:x2]
            # add object to image
            y = max(y, 0)
            x = max(x, 0)
            # 埋め込み範囲のみ重畳描画する、背景画像に重畳していく
            self.composite(fg, img[y:y+fg.shape[0], x:x+fg.shape[1]])

        # ボカし実施
        # randomly apply gaussian blur
        if self.blur_p and rng.random() > self.blur_p:
            img = self.random_blur(img)

        return img, labels
