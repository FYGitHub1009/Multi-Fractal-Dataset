import os
import shutil
import gc
import json
import pickle
import cv2
import numpy as np
from tqdm import tqdm
import threading
from concurrent.futures import ThreadPoolExecutor

from multi_fractal_db import ifs
from multi_fractal_db import serach_ifs_systems
from multi_fractal_db.multi_fractal_dataset import MultiFractalDataset
from multi_fractal_db.multi_fractal_generator import MultiGenerator

class Generator():
    @classmethod
    def get_params(cls, params_path):
        # デバッグ表示
        cls.debug = True

        # Conner's FractalDBのパラメータ
        with open(os.path.join(params_path, 'multi_fractal_ifs_params.json')) as f:
            cls.ifs_params = json.load(f)

        # IFSシステムの探索パラメータ
        kwargs = dict(
          # IFSシステム数 
          num_systems=cls.ifs_params["num_systems"],
          # 連立方程式の数
          n=(2, 4),
          bval=1,
          beta=None,
          sample_fn=None,
        )
        # 全IFSシステムのパラメータ作成
        sys = serach_ifs_systems.random_systems(**kwargs)
        cls.ifs_systems = {'params': sys, 'hparams': kwargs}

        # デバッグモード
        cls.debug = True

        return True

    @classmethod
    def generate(cls, out_path):
        if cls.debug:
            print(out_path)

        # MixUp元フォルダ作成
        base_path = out_path.replace("pretrain", "base")

        # クラス数
        num_classes = cls.ifs_params['num_classes']
        # 1クラスあたりの画像枚数
        num_image_per_class = cls.ifs_params['num_image_per_class']
        
        # 全クラス分の画像作成
        for iclass in range(num_classes):
            print(f"iclass = {iclass:05}")

            # Threadプール作成
            futures = []
            with ThreadPoolExecutor(max_workers=2) as pool:
                # MixUp元ベースクラス作成
                for ib, ibase in enumerate([iclass*2, iclass*2+1]):
                    # クラスフォルダ
                    class_dir = os.path.join(base_path, f"{ibase:05}")
                    #if os.path.exists(class_dir)==False:
                    #    os.makedirs(class_dir)
                    
                    # 1クラスあたりのIFSシステム数
                    num_systems_per_calss = cls.ifs_params['num_systems_per_calss']
                    # 使用するIFSシステムパラメータ
                    st = ibase * num_systems_per_calss
                    en = (ibase+1)*num_systems_per_calss
                    ifs_syss =  {'params':cls.ifs_systems['params'][st:en], 
                                 'hparams': cls.ifs_systems['hparams']}
                    
                    # chaceサイズ
                    #cache_size = num_systems_per_calss * num_image_per_class
                    cache_size = min(500, num_image_per_class*num_systems_per_calss)

                    # 別スレッドで実行
                    future =  pool.submit(make_multi_fractal_images, 
                                ifs_syss, cls.ifs_params, num_systems_per_calss, 
                                num_image_per_class, cache_size, cls.debug, out_path, ibase)
                    futures.append(future)
            
            # 結果取得
            base_images = []
            for future in futures:
                base_images.append(future.result())
        
            # MixUp画像作成
            # クラスフォルダ
            class_dir = os.path.join(out_path, f"{iclass:05}")
            if os.path.exists(class_dir)==False:
                os.makedirs(class_dir)
            
            # 全画像作成
            for idx in tqdm(range(num_image_per_class)):
                # MixUp元画像の読み込み
                #base_dir = os.path.join(base_path, f"{iclass*2:05}")
                #image_file = os.path.join(base_dir, f"{idx:05}.png")
                #image_base1 = cv2.imread(image_file).astype(np.float32)
                image_base1 = base_images[0][idx]
                #base_dir = os.path.join(base_path, f"{iclass*2+1:05}")
                #image_file = os.path.join(base_dir, f"{idx:05}.png")
                #image_base2 = cv2.imread(image_file).astype(np.float32)
                image_base2 = base_images[1][idx]               
                # MixUp
                alpha = 1.0
                lam = np.clip(np.random.beta(alpha, alpha), 0.4, 0.6)
                image_mixup = lam * image_base1 + (1 - lam) * image_base2
                image_mixup = image_mixup.astype(np.uint8)
                # 画像書き出し
                image_file = os.path.join(class_dir, f"{idx:05}.png")
                cv2.imwrite(image_file, image_mixup)
            
            # MixUp元フォルダの削除
            #base_dir = os.path.join(base_path, f"{iclass*2:05}")
            #shutil.rmtree(base_dir)
            #base_dir = os.path.join(base_path, f"{iclass*2+1:05}")
            #shutil.rmtree(base_dir)
            base_images = None
            del base_images
            futures = None
            del futures
            gc.collect()


def make_multi_fractal_images(ifs_systems, ifs_params,
                            num_systems_per_calss, num_image_per_class, cache_size,
                            debug, out_path, ibase):
    # Conner's Multi-FractalDB
    multi_fractal_dataset = MultiFractalDataset(
    ifs_params=ifs_systems,
    num_systems=num_systems_per_calss,
    num_class=1,
    per_class=num_image_per_class,
    generator=MultiGenerator(
        color=ifs_params["color"],
        background=ifs_params["background"],
        niter=ifs_params["niter"],
        patch=ifs_params["patch"],
        n_objects=ifs_params["n_objects"],
        size_range=ifs_params["size_range"],
        jitter_params=ifs_params["jitter_params"],
        cache_size=cache_size,
        size=ifs_params["image_size"]
        ),
    period=2)

    if debug:
        # 確認用フォルダ
        check_dir = out_path.replace("pretrain", "check")
        if os.path.exists(check_dir)==False:
            os.makedirs(check_dir)
        # 使用するIFSフラクタルを描画          
        for i, sys in enumerate(ifs_systems['params']):
            image_gray = multi_fractal_dataset.generator.render(sys['system'])
            image_gray = (image_gray * 255).astype(np.uint8)
            #image_gray = cv2.applyColorMap(image_gray, cv2.COLORMAP_BONE)
            image_file = os.path.join(check_dir, f"{ibase:05}_{i:02}.png")
            cv2.imwrite(image_file, image_gray)

    # 全画像数
    base_images = []
    num_fractal_images = len(multi_fractal_dataset)
    for idx in range(num_fractal_images):
        # 画像とラベルの取得
        image, labels = multi_fractal_dataset[idx]
        # 画像書き出し
        #image_file = os.path.join(class_dir, f"{idx:05}.png")
        #cv2.imwrite(image_file, image)
        base_images.append(image)
    
    # メモリ解放
    multi_fractal_dataset = None
    del multi_fractal_dataset
    gc.collect()

    return base_images